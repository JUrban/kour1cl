Compile main.tex from the archive root with XeLaTeX (or pdfLaTeX) and BibTeX, or with Tectonic. main.bbl and the compiled figure are included. No shell escape or network retrieval is required when the TeX packages are installed.

The anc directory contains the complete portable carpet proof certificates. Run its three checks from anc; see README.md.

The title page includes the author order and affiliations supplied by the organizers. This archive has not been uploaded. The companion full source archive includes measurements, review records, and reproducibility scripts.
